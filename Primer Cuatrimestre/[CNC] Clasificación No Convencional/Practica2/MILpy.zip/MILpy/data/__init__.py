"""
Load Data

"""
__name__ = 'data'
__version__ = '1.0'
from .load_data import load_data
