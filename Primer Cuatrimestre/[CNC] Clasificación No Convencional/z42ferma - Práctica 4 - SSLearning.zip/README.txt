# Prácticas de Clasificación No Convencional

Es recomendable abrir los .ipynb con Google Colab para que funcione todo correctamente. He añadido widgets para cambiar algunos parámetros que solo se
pueden ver en Google Colab.

El enlace es el siguiente:
https://drive.google.com/drive/folders/1vuTNs9cphXAOoCfBdIq4s2MR15nex6tC?usp=sharing