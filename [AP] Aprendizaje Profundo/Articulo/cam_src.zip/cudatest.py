import torch

print(torch.cuda.device_count())