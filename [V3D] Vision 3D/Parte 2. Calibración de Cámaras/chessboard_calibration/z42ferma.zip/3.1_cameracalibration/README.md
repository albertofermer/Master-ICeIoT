## Pasos para compilar y ejecutar el programa
1. mkdir build
2. cd build
3. cmake ..
4. make
5. ./calibration ../calibration
6. ./augReal 3 intrisics.yml ../video/augreal.mp4
