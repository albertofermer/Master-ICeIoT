# Lo que he hecho

He implementado todas las funciones de la prácica, sin embargo, creo que hay un error al ejecutar el programa principal ya que el filtro gaussiano se
aplica cada vez que se actualiza la ventana y termina deformando la imagen.

# Lo que no he hecho

# Enlace al vídeo descriptivo
https://youtu.be/wj7NGQtgyiQ

# Comandos
./edge_detector ../data/mini-berkely/2018.jpg output.jpg ../data/2018_gt.png