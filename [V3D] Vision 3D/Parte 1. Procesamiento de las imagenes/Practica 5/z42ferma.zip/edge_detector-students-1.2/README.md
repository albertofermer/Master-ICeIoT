# Edge detectors

Puedes ver la descripción de la práctica [[aquí](https://docs.google.com/document/d/1zD--37WVqbv00rd7X_nFX2UEXFbr6iXEXfNCDdvFPZY/edit?usp=sharing)].