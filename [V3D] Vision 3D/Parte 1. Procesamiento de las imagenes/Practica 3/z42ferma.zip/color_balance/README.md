# Equilibrado del color

La descripción de esta práctica la puedes ver [aquí](https://docs.google.com/document/d/1eXCv4QR6dWD2nRB3f-6WHFBlQCp12aYT_DeiahuKpvg/edit?usp=sharing).

