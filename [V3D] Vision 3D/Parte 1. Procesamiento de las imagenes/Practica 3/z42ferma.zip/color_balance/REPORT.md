# Lo que he hecho

He implementado todas las funcionalidades de la práctica

# Lo que no he hecho

# Enlace al vídeo descriptivo
https://youtu.be/jj3UkTPPt0s

# Comandos
./color_balance -i ../data/cena-romántica-con-velas-y-vino.jpg ../data/cena-romántica-con-velas-y-vino.jpg
