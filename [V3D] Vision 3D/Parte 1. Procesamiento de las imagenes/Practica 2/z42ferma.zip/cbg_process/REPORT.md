# Lo que he hecho

He implementado todas las funciones que pide la práctica.

# Lo que no he hecho

# Enlace al vídeo descriptivo

https://youtu.be/NWmijHi-900

# Comandos
./cbg_process -i ../data/gray_levels.png ../data/gray_levels.png
./cbg_process -i ../data/ciclista_original.jpg ../data/ciclista_original.jpg