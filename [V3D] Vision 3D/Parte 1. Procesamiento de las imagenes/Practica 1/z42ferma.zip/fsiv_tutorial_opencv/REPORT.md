# Lo que he hecho

He realizado todas las funciones que piden en la practica.
# Lo que no he hecho

# Enlace al vídeo descriptivo
https://youtu.be/7PEdqujADvw

# Comandos
./show_extremes ../data/ciclista_original.jpg
./show_extremes -v ../data/campus_000_002.avi
