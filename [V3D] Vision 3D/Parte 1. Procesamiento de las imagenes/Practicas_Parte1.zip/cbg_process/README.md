# Control del contraste, brillo y gamma de una imagen digital.

Ver la descripción de la práctica [[aquí](https://docs.google.com/document/d/1-r3J_JklP2pNpH8OPcJpuQQlNgkxiRY_5JvS6KvWa74/edit?usp=sharing)].
