# Realce usando máscara de desenfoque (Unsharp Mask).

La descripción de la práctica la tienes [[aquí](https://docs.google.com/document/d/1n901PwKfRoa1JGpj9VzzUyc3bPtbY7khjcwgBkHLzTM/edit?usp=sharing)]
