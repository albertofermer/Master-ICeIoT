# Lo que he hecho

He implementado todas las funcionalidades de la práctica

# Lo que no he hecho

# Enlace al vídeo descriptivo
https://youtu.be/BVCoJ8QtD3A
# Comandos
./usm_enhance -i ../data/cells.png ../data/cells.png